﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmitMapper.EmitInvoker
{
    public abstract class MethodInvokerFunc_1 : MethodInvokerBase
    {
        public abstract object CallFunc(object param1);
    }

}
