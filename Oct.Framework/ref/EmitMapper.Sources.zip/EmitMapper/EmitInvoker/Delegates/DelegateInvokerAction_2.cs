﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmitMapper.EmitInvoker
{
    public abstract class DelegateInvokerAction_2 : DelegateInvokerBase
    {
        public abstract void CallAction(object param1, object param2);
    }
}
