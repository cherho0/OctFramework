﻿namespace EmitMapper.AST.Interfaces
{
    interface IAstValue : IAstRefOrValue
    {
    }
}