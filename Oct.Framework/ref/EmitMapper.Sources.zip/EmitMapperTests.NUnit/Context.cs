﻿using EmitMapper;

namespace EmitMapperTests
{
    class Context
    {
        public static ObjectMapperManager objMan = new ObjectMapperManager();
    }
}